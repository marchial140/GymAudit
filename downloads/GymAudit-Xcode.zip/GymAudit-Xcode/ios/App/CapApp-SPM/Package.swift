// swift-tools-version: 5.9
import PackageDescription

// Copie autonome pour Xcode, produite par scripts/package-xcode.py
let package = Package(
    name: "CapApp-SPM",
    platforms: [.iOS(.v15)],
    products: [
        .library(
            name: "CapApp-SPM",
            targets: ["CapApp-SPM"])
    ],
    dependencies: [
        .package(name: "capacitor-swift-pm", path: "../../NativePackages/capacitor-swift-pm"),
        .package(name: "CapacitorClipboard", path: "../../NativePackages/clipboard"),
        .package(name: "CapacitorShare", path: "../../NativePackages/share"),
        .package(name: "CapacitorStatusBar", path: "../../NativePackages/status-bar")
    ],
    targets: [
        .target(
            name: "CapApp-SPM",
            dependencies: [
                .product(name: "Capacitor", package: "capacitor-swift-pm"),
                .product(name: "Cordova", package: "capacitor-swift-pm"),
                .product(name: "CapacitorClipboard", package: "CapacitorClipboard"),
                .product(name: "CapacitorShare", package: "CapacitorShare"),
                .product(name: "CapacitorStatusBar", package: "CapacitorStatusBar")
            ]
        )
    ]
)
